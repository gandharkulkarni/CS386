module.exports = {
	mongo: {
		connectionString: 'mongodb+srv://gakulkarni:cs386@fullstackwebdev.cscb82e.mongodb.net/USF_CS386?retryWrites=true&w=majority'
	}
};